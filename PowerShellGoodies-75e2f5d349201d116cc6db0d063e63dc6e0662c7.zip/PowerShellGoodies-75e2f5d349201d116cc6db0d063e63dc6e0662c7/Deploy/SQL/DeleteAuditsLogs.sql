USE [LogsListSQLDatabase]
GO

Delete from [dbo].[Audit]
GO