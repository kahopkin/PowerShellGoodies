This zip-file supports the article;
https://www.howto-outlook.com/howto/contactnameformat.htm

If you downloaded this file from any other location, please visit the
above page to download a fresh copy as it is the only way I can assure
you that you've downloaded a malware free version.

Best regards and enjoy!
Robert Sparnaaij aka Roady